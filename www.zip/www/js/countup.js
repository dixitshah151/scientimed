'use strict';

/*
 Theme Name: CarePro - Bootstrap HTML template
 Description: Custom JS are defined in this class
 Author: Jyostna
 Author URI: http://themeforest.net/user/jyostna
 Version: 1.0

 -------------------------------------------- */
/**
 */
/*-------------Code for countup-------------*/

$(document).ready(function(){

    var index6_count1 = $("#index6_count1");
    var aboutus_count1 = $("#aboutus_count1");
    var aboutus_count2 = $("#about_count2");

    if (typeof CountUp === "function") {
        var options = {useEasing: true, useGrouping: true, separator: '', decimal: '.', prefix: '', suffix: ''};
        /*-------------Index---------------*/
        if (index6_count1[0]) {
            var count1 = new CountUp("index6_count1", 0, 32, 0, 5, options);
            var count2 = new CountUp("index6_count2", 0, 256, 0, 2.5, options);
            var count3 = new CountUp("index6_count3", 0, 651, 0, 5, options);
            var count4 = new CountUp("index6_count4", 0, 45, 0, 5, options);
        }

        if (aboutus_count1[0]) {
            var count5 = new CountUp("aboutus_count1", 0, 75, 0, 5, options);
            var count6 = new CountUp("aboutus_count2", 0, 3520, 0, 2.5, options);
            var count7 = new CountUp("aboutus_count3", 0, 15, 0, 5, options);
            var count8 = new CountUp("aboutus_count4", 0, 20, 0, 5, options);

        }

        if (aboutus_count2[0]) {
            var count9 = new CountUp("about_count2", 0, 13000, 0, 2.5, options);
        }

        $(window).on('scroll', function () {
            var winTop = $(window).scrollTop();
            var winHeight = $(window).height();
            var animation1 = $('#index6_count1,#aboutus_count1,#about_count2').offset().top + parseInt(200);
            if (winTop >= (animation1 - winHeight)) {
                if (index6_count1[0]) {
                    count1.start();
                    count2.start();
                    count3.start();
                    count4.start();
                }


                if (aboutus_count1[0]) {
                    count5.start();
                    count6.start();
                    count7.start();
                    count8.start();
                }
            }

            if (aboutus_count2[0]) {
                count9.start();
            }

        });

    }
});