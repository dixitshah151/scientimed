'use strict';
/*
 Theme Name: CarePro - Bootstrap HTML template
 Description: Custom JS are defined in this class
 Author: Jyostna
 Author URI: http://themeforest.net/user/jyostna
 Version: 1.0

 -------------------------------------------- */

/*================Code for video==================*/
$(document).ready(function(){
    var players = plyr.setup({
        fullscreen:{
            enabled: false
        }
    });
    $("#modal-video").on("hidden.bs.modal", function(){
        players[0].pause();
    });
});

