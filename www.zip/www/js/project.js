var app = angular.module("scientimed", ["ngRoute"]);
var apipath="https://scientimed.com/scientimedapi/Scientimedapi/";
var path=document.URL;

// alert(path);

app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "home.html",
        controller:"getbanner"
    })
    .when("/aboutus", {
        templateUrl : "aboutus.html",
        controller:"about_intern"
    })
    .when("/strategicconsultant", {
        templateUrl : "strategicconsultant.html",
        controller:"strategicconsultant"
    })
    .when("/healthcare", {
        templateUrl : "healthcare.html",
        controller:"healthcare"
    })
    .when("/career", {
        templateUrl : "career.html",
        controller:"career"
    })
    .when("/contact", {
        templateUrl : "contact.html",
        controller:"contact"
    })
    .otherwise({
        templateUrl:"404"
    });
    
});
app.controller("contact_scientimed",function($scope,$http,$window,$route,$timeout){
    $scope.contact_btn=function(){

        // alert(1111);
        $http.post(apipath+"contact_validation/",$scope.formdata).then(function(res){
            $scope.result=res.data;

            // alert(res.data);
             // if(res.data == 1)
             // {
             //    $scope.result="We Will Contact You Shortly";
               
             //        $timeout(function () {
             //             $route.reload();
             //        }, 15000);
             // }
             // else
             // {
             //     $scope.result=res.data;
             // }
        })
        // alert(1111);
    }
})



app.controller("getbanner",function($scope,$http){
    var getbannerpath=apipath+"getbanner";
    
    $http.get(getbannerpath).then(function(res){
      
        $scope.getbannerdata=res.data
    })
})