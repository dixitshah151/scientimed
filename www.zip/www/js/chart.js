'use strict';
/*
 Theme Name: CarePro - Bootstrap HTML template
 Description: Custom JS are defined in this class
 Author: Jyostna
 Author URI: http://themeforest.net/user/jyostna
 Version: 1.0

 -------------------------------------------- */

/*=========Code for charts===============*/

$(document).ready(function(){
    var da2 = [["2005", 10],["06", 30],["07", 50],["08", 60],["09", 50],["10", 50],["11", 30],["12", 40],["13", 40],["14", 50],["15", 60],["16", 70]];
    $.plot("#area-chart", [{

        data: da2,
        label: "Growth",
        color: "#107fc9"
    }], {
        series: {
            lines: {
                show: !0,
                fill: .8,
                fillColor: { colors: [{ opacity: 0.0 }, { opacity: 0.6}] }
            },
            points: {
                show: !0,
                radius: 3
            }
        },
        grid: {
            borderColor: "#fff",
            borderWidth: 1,
            hoverable: !0
        },
        tooltip: true,
        tooltipOpts: {
            content: "%y",
            defaultTheme: true
        },
        xaxis: {
            tickColor: "#eff",
            mode: "categories"
        },
        yaxis: {
            tickColor: "#eff"
        },
        shadowSize: 0
    });
});