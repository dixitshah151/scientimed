'use strict';
/*
 Theme Name: CarePro - Bootstrap HTML template
 Description: Custom JS are defined in this class
 Author: Jyostna
 Author URI: http://themeforest.net/user/jyostna
 Version: 1.0

 -------------------------------------------- */

/*===========Code for timer==============*/
$(document).ready(function(){
    function getTimeRemaining(endtime) {
        var t = Date.parse(endtime) - Date.parse(new Date());
        var seconds = Math.floor((t / 1000) % 60);
        var minutes = Math.floor((t / 1000 / 60) % 60);
        var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
        var days = Math.floor(t / (1000 * 60 * 60 * 24));
        return {'days': days,'hours': hours,'minutes': minutes,'seconds': seconds};
    }
    function initializeClock(id,endtime) {
        var clock = document.getElementById(id);
        var daysSpan = clock.querySelector('.days');
        var hoursSpan = clock.querySelector('.hours');
        var minutesSpan = clock.querySelector('.minutes');
        var secondsSpan = clock.querySelector('.seconds');
        function updateClock() {
            var t = getTimeRemaining(endtime);
            daysSpan.innerHTML = t.days+" Days";
            hoursSpan.innerHTML = ('0' + t.hours).slice(-2)+" h";
            minutesSpan.innerHTML = ('0' + t.minutes).slice(-2)+" m";
            secondsSpan.innerHTML = ('0' + t.seconds).slice(-2)+" s";
            if (t.total <= 0) {
                clearInterval(timeinterval);
            }
        }
        updateClock();
        var timeinterval = setInterval(updateClock, 1000);
    }
    var deadline1 = new Date(Date.parse(new Date()) + 70 * 50 * 58 * 10 * 1000);
    var deadline2 = new Date(Date.parse(new Date()) + 80 * 63 * 36 * 25 * 1000);
    var deadline3 = new Date(Date.parse(new Date()) + 95 * 45 * 25 * 50 * 1000);
    initializeClock("timer1",deadline1);
    initializeClock("timer2",deadline2);
    initializeClock("timer3",deadline3);
});
